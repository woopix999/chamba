﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_16
{
    internal class Зfдfние_16
    {
        private double _y;
        

        public Зfдfние_16(double y)
        {
            _y = y;
           
        }
        public void S()
        {
            Console.WriteLine($"S = {Math.Sqrt(Math.Cos(4) * Math.Pow(y, 2) + 7.151)}");
        }
    }
}
