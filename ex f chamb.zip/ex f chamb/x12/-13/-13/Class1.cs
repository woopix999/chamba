﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13
{
    class Class1
    {
        class ArrayProcessor
        {
            private int[] array;
            private int sum;

            public ArrayProcessor()
            {
                array = new int[11];
                sum = 0;
            }

            public void InputArray()
            {
                Console.WriteLine("Введите 11 элементов массива:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write($"Элемент {i + 1}: ");
                    array[i] = int.Parse(Console.ReadLine());
                }
            }

            public void CalculateSumOfOddNegatives()
            {
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] < 0 && array[i] % 2 != 0)
                    {
                        sum += array[i];
                    }
                }
            }

            public void ReplaceMultiplesOfThree()
            {
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] % 3 == 0)
                    {
                        array[i] = sum;
                    }
                }
            }

            public void PrintResults()
            {
                Console.WriteLine("\nМассив после замены:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write($"{array[i]} ");
                }

                Console.WriteLine($"\n\nСумма нечетных отрицательных элементов: {sum}");
            }
        }

        class Program
        {
            static void Main()
            {
                ArrayProcessor processor = new ArrayProcessor();

                processor.InputArray();
                processor.CalculateSumOfOddNegatives();
                processor.ReplaceMultiplesOfThree();
                processor.PrintResults();
            }
        }
    }
}
