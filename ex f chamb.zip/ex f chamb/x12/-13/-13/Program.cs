﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13
{
    class Program
    {
        
            static void Main()
            {
                int[] array = new int[11];
                int sum = 0;

                // Ввод массива
                Console.WriteLine("Введите 11 элементов массива:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write($"Элемент {i + 1}: ");
                    array[i] = int.Parse(Console.ReadLine());
                }

                // Вычисление суммы нечетных по значению отрицательных элементов
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] < 0 && array[i] % 2 != 0)
                    {
                        sum += array[i];
                    }
                }

                // Замена элементов, кратных трем, на сумму
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] % 3 == 0)
                    {
                        array[i] = sum;
                    }
                }

                // Вывод результатов
                Console.WriteLine("\nМассив после замены:");
                for (int i = 0; i < array.Length; i++)
                {
                    Console.Write($"{array[i]} ");
                }

                Console.WriteLine($"\n\nСумма нечетных отрицательных элементов: {sum}");
            }
        
    }
}
